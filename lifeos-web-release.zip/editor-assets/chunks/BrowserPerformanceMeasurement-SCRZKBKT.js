import{a}from"./chunk-O6FV33P2.js";import"./chunk-7SZRL6FY.js";export{a as BrowserPerformanceMeasurement};
