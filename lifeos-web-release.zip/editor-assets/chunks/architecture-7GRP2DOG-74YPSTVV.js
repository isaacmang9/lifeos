import{a as e,b as r}from"./chunk-GTOR5LH3.js";import"./chunk-6TXPMWAD.js";import"./chunk-7SZRL6FY.js";export{e as ArchitectureModule,r as createArchitectureServices};
