import{a as o,b as e}from"./chunk-L4XWBPGI.js";import"./chunk-MGM2PZKY.js";import"./chunk-FXNSCOHY.js";import"./chunk-K2DIQIQO.js";import"./chunk-2XIQHMUM.js";import"./chunk-3TA6SVGO.js";import"./chunk-G36CQTYX.js";import"./chunk-ZXUHA55X.js";import"./chunk-I3HIAEWT.js";import"./chunk-OLL2TIJQ.js";import"./chunk-6VHTXLOP.js";import"./chunk-4PJNGS3V.js";import"./chunk-ZDEIXIU6.js";import"./chunk-NMQEZKAK.js";import"./chunk-LC7E4BNT.js";import"./chunk-3Q7H3ZDF.js";import"./chunk-TPRRJFRN.js";import"./chunk-4LRBRCL6.js";import"./chunk-C7Z6JGVT.js";import"./chunk-JFREIVYM.js";import{a as r}from"./chunk-OIDPAYYJ.js";import"./chunk-7SZRL6FY.js";var m=r(t=>`${o(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),i=m,B=e({defaultLayout:"swimlane",styles:i});export{B as diagram};
