import{a as e,b as r}from"./chunk-6IYPIPEE.js";import"./chunk-6TXPMWAD.js";import"./chunk-7SZRL6FY.js";export{e as PacketModule,r as createPacketServices};
