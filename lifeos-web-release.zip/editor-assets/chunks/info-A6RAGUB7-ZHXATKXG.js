import{a as o,b as e}from"./chunk-TQ4R37DD.js";import"./chunk-6TXPMWAD.js";import"./chunk-7SZRL6FY.js";export{o as InfoModule,e as createInfoServices};
